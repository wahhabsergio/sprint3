# Grupo Softesc - 1TDSB

## Integrantes
- RM 558821 - Cauan Matos Moura Silva
- RM 557886 - Eduardo Guilherme Dias
- RM 555901 - Sérgio Henrique dos Santos Wahhab


## Link do Vídeo no YT
https://www.youtube.com/watch?v=o6vwDjerIkY


## Repositório GitHub
https://github.com/wahhabsergio/sprint3
