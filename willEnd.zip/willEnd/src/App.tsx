
import Navbar from './Components/Header/Navbar'
import './Styles/Style.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Footer from './Components/Footer/Footer'
import Diagnostico from './Containers/Diagnostico/Diagnostico'
import Login from './Containers/PageLogin/Login'
import Services from './Containers/Services/Index'
import Sobre from './Containers/Sobre/Sobre'
import Home from './Containers/Home/Home'

function App() {

  return (
    <>
      <BrowserRouter>

        <Navbar />

        <Routes>

        <Route path="/" element={ <Home/> }></Route>
          <Route path="/login" element={<Login />}></Route>
          <Route path="/servicos" element={<Services />}></Route>
          <Route path="/sobre" element={<Sobre />}></Route>
          <Route path="/diagnostico" element={<Diagnostico />} ></Route>
        </Routes>

        <Footer />

      </BrowserRouter>

    </>
  )
}

export default App
