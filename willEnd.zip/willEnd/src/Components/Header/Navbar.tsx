import './NavFront.css'
import { Link } from 'react-router-dom';

const Navbar = () =>{

    return (
        <>
            <header>
                <nav className="navigation">
                <img src="/Images/porto-seguro-original.png" alt="Logo PortoSeguro" className='logo' />
                    <ul>
                        <li><Link to="/">Início</Link></li>
                        <li><Link to="/servicos">Serviços</Link></li>
                        <li><Link to="/login">Login</Link></li>
                        <li><Link to="/sobre">Sobre</Link></li>
                    </ul>

                    <button className="btn-default">
                        <Link to="/diagnostico">Diagnosticar Meu Carro</Link>
                    </button>

                </nav>
            </header>
        </>
    )

}

export default Navbar;