import './FooterFront.css';

const Footer = () => {

    return (

        <>
            <footer>
                <div className="footer-container">
                    <div className="footer-column">
                        <h3>Will </h3>
                        <ul>
                            <li><a href="#">Diagnóstico</a></li>
                            <li><a href="#">Panoramas</a></li>
                            <li><a href="#">Orçamentação</a></li>
                        </ul>
                    </div>
                    <div className="footer-column">
                        <h3>Tecnologias</h3>
                        <ul>
                            <li><a href="#">Watson</a></li>
                            <li><a href="#">Html, Css and JavaScript</a></li>
                            <li><a href="#">Python</a></li>
                        </ul>
                    </div>
                    <div className="footer-column">
                        <h3>Vendas</h3>
                        <ul>
                            <li><a href="#">Orçamentação</a></li>
                            <li><a href="#">Oportunidade Audi</a></li>
                            <li><a href="#">Vendas Diretas e Corporativas</a></li>
                            <li><a href="#">Signature</a></li>
                            <li><a href="#">Seminovos Audi Approved :plus</a></li>
                            <li><a href="#">Audi Financial Services</a></li>
                            <li><a href="#">Audi Pass</a></li>
                        </ul>
                    </div>
                    <div className="footer-column">
                        <h3>Serviços ao Cliente</h3>
                        <ul>
                            <li><a href="#">Rede Concessionária</a></li>
                            <li><a href="#">Preço Revisão Audi</a></li>
                            <li><a href="#">Audi Service Express</a></li>
                        </ul>
                    </div>
                </div>
                <div className="footer-bottom">
                    <p>&copy; 2024 Will AG. All Rights Reserved.</p>
                </div>


            </footer>
        </>
    )
}

export default Footer;