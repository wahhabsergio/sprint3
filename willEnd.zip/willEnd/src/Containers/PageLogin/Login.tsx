import { Link } from 'react-router-dom';
import './Page.css'

const Login = () => {

    return (
        <div className="container">
            <div className="login-section">
                <form className="login-form" action="/diagnostico-original" method="post">
                    <h2>Faça login para continuar</h2>

                    <label htmlFor="email">E-mail</label>
                    <input type="email" id="email" name="email" placeholder="E-mail" required />

                    <label htmlFor="password">Senha de acesso</label>
                    <input type="password" id="password" name="password" placeholder="Senha de acesso" required />

                    <Link to="/forgot-password" className="forgot-password">Esqueci minha senha</Link>

                    <button type="submit">Entrar</button>

                    <div className="alternative-login">
                        <p>ou</p>
                        <button type="button" className="google-login">Continuar com Google</button>
                        <button type="button" className="apple-login">Continuar com Apple</button>
                    </div>

                    <p className="signup">
                        Ainda não tem conta? <Link to="/signup">Cadastre-se com e-mail e senha</Link>
                    </p>
                </form>
            </div>
            <div className="info-section">
                <div className="info-content">
                    <h1>
                        Encontre a <span>oficina ideal</span>, <span>agende online</span> e tenha a certeza de um <span>serviço de qualidade</span>.
                    </h1>
                    <p>
                        Com o <span>Will</span>, você economiza tempo e dinheiro, dirige com mais segurança e tranquilidade.
                    </p>
                </div>
            </div>
        </div>
    )
}

export default Login;
