import React from 'react';
import './Duvidas.css'; 

const Duvidas = () => {
    
    const scrollToTop = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => {
        event.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    return (
        
        <>
            <div className="container">
                <h1>Política de Privacidade</h1>
                <p>Esta é um breve resumo da Política de Privacidade.</p>
                <p>1. Obrigações: Para fins desta Política de Privacidade, aplicam-se as seguintes definições: dados pessoais são todas as informações relacionadas aos usuários do site.</p>
                <p>2. Coleta de dados: As informações e dados pessoais do usuário são coletados por meio de diversas ferramentas oferecidas no site, fornecidos pelo próprio usuário voluntariamente ou obtidos automaticamente através dos canais de comunicação disponíveis no site.</p>
                <p>3. Armazenamento de dados: Todos os dados e informações coletados são armazenados em ambiente seguro, observando as diretrizes de confidencialidade e segurança estabelecidas pela Minha Revisão.</p>
                <p>4. Uso dos dados: Os dados coletados são utilizados para as finalidades descritas nesta Política de Privacidade.</p>
                <p>5. Cookies: O site pode fazer uso de cookies para coletar informações sobre a navegação do usuário.</p>
                <p>6. Aplicabilidade: A presente Política de Privacidade aplica-se ao site e a todos os serviços oferecidos pela Minha Revisão.</p>
            </div>

            <div className="footer-container">
                <div className="footer-column">
                    <h3>Will</h3>
                    <ul>
                        <li><a href="#">Diagnóstico</a></li>
                        <li><a href="#">Panoramas</a></li>
                        <li><a href="#">Orçamentação</a></li>
                        <li><a href="#"></a></li>
                        <li><a href="#">Mulheres Audi</a></li>
                        <li><a href="#">Trabalhe Conosco</a></li>
                        <li><a href="#">Canal de Denúncia</a></li>
                    </ul>
                </div>
                <div className="footer-column">
                    <h3>Tecnologias</h3>
                    <ul>
                        <li><a href="#">Audi Connect Plug and Play</a></li>
                        <li><a href="#">Tecnologias Audi</a></li>
                        <li><a href="#">Ruído veicular externo</a></li>
                    </ul>
                </div>
                <div className="footer-column">
                    <h3>Vendas</h3>
                    <ul>
                        <li><a href="#">Modelos</a></li>
                        <li><a href="#">Oportunidade Audi</a></li>
                        <li><a href="#">Vendas Diretas e Corporativas</a></li>
                        <li><a href="#">Signature</a></li>
                        <li><a href="#">Seminovos Audi Approved :plus</a></li>
                        <li><a href="#">Audi Financial Services</a></li>
                        <li><a href="#">Audi Pass</a></li>
                    </ul>
                </div>
                <div className="footer-column">
                    <h3>Serviços ao Cliente</h3>
                    <ul>
                        <li><a href="#">Rede Concessionária</a></li>
                        <li><a href="#">Preço Revisão Audi</a></li>
                        <li><a href="#">Audi Service Express</a></li>
                        <li><a href="#">Audi Class Service</a></li>
                        <li><a href="#">Garantia</a></li>
                        <li><a href="#">Garantia Estendida</a></li>
                        <li><a href="#">Revisões Planejadas Audi</a></li>
                        <li><a href="#">Consulta Recall</a></li>
                        <li><a href="#">Oficina Portas Abertas</a></li>
                        <li><a href="#">Ficha de Resgate Veicular</a></li>
                    </ul>
                </div>
            </div>
            <div className="footer-bottom">
                <p>&copy; 2024 AUDI AG. All Rights Reserved.</p>
                <ul className="footer-links">
                    <li><a href="#">Termos de Uso</a></li>
                    <li><a href="#">Políticas de Privacidade</a></li>
                    <li><a href="#">Código de Conduta</a></li>
                    <li><a href="#">Proteção de Dados - LGPD</a></li>
                    <li><a href="#">Sala de Imprensa</a></li>
                    <li><a href="#">Contato</a></li>
                </ul>
            </div>
            <a href="#" id="back-to-top" onClick={scrollToTop}>Voltar ao topo</a>
        </>
    )
}

export default Duvidas;
