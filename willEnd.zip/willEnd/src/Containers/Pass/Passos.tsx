import './Pass.css';

const Passos = () => {

    return (
        <>
            <section id="Passos">
                <div className="step-container">
                    <div className="steps">
                        <h1>Passo a passo de como fazer seu Diagnóstico</h1>
                        <p>Todo o processo é simples, rápido e seguro.</p>
                        <div className="step">
                            <div className="step-icon">1</div>
                            <div className="step-details">
                                <h2>Nos forneça informações</h2>
                                <p>Forneça informações sobre o modelo, placa e ano do carro e o que está acontecendo.</p>
                            </div>
                        </div>
                        <div className="step">
                            <div className="step-icon">2</div>
                            <div className="step-details">
                                <h2>Lhe daremos o Panorama</h2>
                                <p>Iremos disponibilizar um panorama sobre as informações passadas.</p>
                            </div>
                        </div>
                        <div className="step">
                            <div className="step-icon">3</div>
                            <div className="step-details">
                                <h2>Daremos o Diagnóstico</h2>
                                <p>Após o panorama disponibilizamos o diagnóstico.</p>
                            </div>
                        </div>
                        <div className="step">
                            <div className="step-icon">4</div>
                            <div className="step-details">
                                <h2>Login</h2>
                                <p>Após o Diagnóstico faça o Login para receber o orçamento.</p>
                            </div>
                        </div>
                        <div className="step">
                            <div className="step-icon">5</div>
                            <div className="step-details">
                                <h2>Email</h2>
                                <p>Após realizar o Login você receberá o orçamento no Email.</p>
                            </div>
                        </div>
                        <div className="step">
                            <div className="step-icon">6</div>
                            <div className="step-details">
                                <h2>Concluído</h2>
                                <p>Agora é só levar o carro na oficina ou resolver você mesmo.</p>
                            </div>
                        </div>
                    </div>
                    <div className="video-tutorial">
                        <div className="video-box">
                        </div>
                    </div>
                </div>
            </section>
        </>
    )

}

export default Passos;