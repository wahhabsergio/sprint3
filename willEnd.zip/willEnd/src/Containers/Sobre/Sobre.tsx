import './Sobre.css';

const Sobre = () => {

    return (

        <>

            <section id="Sobre">
                <div className="pessoa">
                    <div id="Desc">
                        <div className="feed">
                            <img src="/Images/Cauan.png" id="Avatar" alt="Foto Perfil Cauan" />

                            <div className="feedback">
                                <h4>Cauan Matos</h4>
                                <span>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                </span>
                                <p id="comen">
                                    "Cauan Matos Moura Silva, 18 anos, estudante da <br />
                                    FIAP - Faculdade de Informática e Administração Paulista."
                                </p>
                            </div>
                        </div>
                    </div>

                    <div id="Desc">
                        <div className="feed">
                            <img src="/Images/Edu.png" id="Avatar" alt="Foto perfil Eduardo" />

                            <div className="feedback">
                                <h4>Eduardo Dias</h4>
                                <span>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                </span>
                                <p id="comen">
                                    "Eduardo Guilherme Dias, 18 anos, estudante da <br />
                                    FIAP - Faculdade de Informática e Administração Paulista."
                                </p>
                            </div>
                        </div>
                    </div>

                    <div id="Desc">
                        <div className="feed">
                            <img src="/Images/Sergio.png" id="Avatar" alt="Foto perfil Sergio" />
                            <div className="feedback">
                                <h4>Sérgio Wahhab</h4>
                                <span>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                    <i className="fa-solid fa-star"></i>
                                </span>
                                <p id="comen">
                                    "Sérgio Henrique dos Santos Wahhab, 18 anos, estudante da <br />
                                    FIAP - Faculdade de Informática e Administração Paulista."
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>

    )
}

export default Sobre;
