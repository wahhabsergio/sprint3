
import { Link } from 'react-router-dom';
import './Menu.css'
import Passos from '../Pass/Passos';

const Menu = () => {

    return (
        
    <>
        <section id="home">

            <div className="shape"></div>
            
            <div id="cta">
                <h1 className="Tittle">
                    Diagnóstico agora no
                    <span>WILL</span>
                </h1>

                <p className="description">Otimize seu tempo realizando um diagnóstico através do assistente <span>Will</span>, faça o diagnóstico, orçamentação e tenha seu carro com uma devolutiva rápida.</p>
            
                <div id="cta-buttons">
                    <Link to="/diagnostico" className="btn-default" >Diagnóstico agora </Link>
                     
                </div>

        </div>

        <div id="banner">
            <img src="/Images/porsche-model.png" id="car" alt="porsche-carro" />
            <img src="/Images/caixaferramenta.png" id="caixa" alt="caixa de ferramentas" />
        </div>
    </section>

        <Passos />

        </>

    )

}

export default Menu;