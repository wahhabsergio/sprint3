import './Services.css';
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossOrigin="anonymous" referrerPolicy="no-referrer" />


const Services = () => {

    return (

        <>
            <section id="Serviços">
                <h2 className="section-tittle">Serviços</h2>
                <h3 className="section-sub-tittle">
                    <span>Serviços disponibilizados</span></h3>

                <div id="servicos">
                    <div className="Service">
                        <div className="dish">
                            <i className="fa solid fa heart"></i>
                        </div>

                        <img src="/Images/carrovermelho-removebg-preview.png" id="red" className="carrovermelho" alt="" />

                        <h3 className="tittle-carro">
                            Will Diagnóstico
                        </h3>

                        <span className="descricao">
                            Um diagnóstico através do assistente Will <br />
                            Rápido, prático e com ótima eficiência.
                        </span>

                        <div className="rate">
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <span>(500+)</span>

                            <div className="price">
                                <h4>Avaliação</h4>
                                <a href="Login.html"><button className="btn-default" >
                                <img src="/Images/basket-shopping-solid.png" alt="cesta" id='ca' /></button></a>
                                    
                            </div>
                        </div>
                    </div>
                </div>
                <div id="servicos">
                    <div className="Service">
                        <div className="dish">
                            <i className="fa solid fa heart"></i>
                        </div>

                        <img src="/Images/374-3748589_caixa-de-ferramenta-12-5-stanley-clipart-removebg-preview.png" id="red" className="carrovermelho" alt="Caixa de ferramenta" />

                        <h3 className="tittle-carro">
                            Dúvidas
                        </h3>

                        <span className="descricao">
                            Um canal direcionado aos nossos clientes <br />
                            Que possuem dúvidas sobre o serviço.
                        </span>

                        <div className="rate">
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <span>(128+)</span>

                            <div className="price">
                                <h4>Avaliação</h4>
                                <a href="Login.html"><button className="btn-default" >
                                <img src="/Images/pen.png" alt="cesta" id='ca' /></button></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="servicos">
                    <div className="Service">
                        <div className="dish">
                            <i className="fa solid fa heart"></i>
                        </div>

                        <img src="/Images/robo__2_-removebg-preview.png" alt="" />

                        <h3 className="tittle-carro">
                            Avaliações
                        </h3>

                        <span className="descricao">
                            Que tal dar uma passadinha nesse canal <br />
                            E dar uma avaliação aos colaboradoes?
                        </span>

                        <div className="rate">
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <i className="fa solid fa-star"></i>
                            <span>(220+)</span>

                            <div className="price">
                                <h4>Avaliação</h4>
                                <a href="Login.html"><button className="btn-default" >
                                <img src="/Images/users.png" alt="cesta" id='ca' /></button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>

    )

}

export default Services;