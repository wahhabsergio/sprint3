import React, { useState } from 'react';
import './Diagnostico.css'; 

const Diagnostico = () => {
    
    const [cars, setCars] = useState<string[]>([]);
    const [info, setInfo] = useState<string>('');
    const [email, setEmail] = useState<string>('');

    const addCar = () => {
        setCars([...cars, 'Carro adicionado']);
    };

    const addInfo = () => {
        alert('Informações adicionadas!');
    };

    const getPanorama = () => {
        alert('Panorama recebido!');
    };

    const getDiagnosis = () => {
        alert('Diagnóstico recebido!');
    };

    const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        alert(`Orçamento enviado para ${email}`);
    };

    return (
        <>
            {/* <div className="sidebar">
                <img src="./Images/porto-seguro-original.png" alt="Logo" width="55" />
                <a href="index.html">Início</a>
                <a href="index.html#Serviços">Serviços</a>
                <a href="index.html#Sobre">Sobre</a>
                <a href="index.html#Passos">Preciso de ajuda</a>
                <a href="Duvidas.html">Política de Privacidade</a>
                <div className="user-info">
                    <p>Sem nome</p>
                    <p>cauan13.nm@gmail.com</p>
                    <button className="logout" onClick={() => alert('Você saiu da conta.')}>Sair da conta</button>
                </div>
            </div> */}
            <div className="content">
                <div className="header">
                    <h1>Cadastrar <span>Carro</span></h1>
                </div>
                <div className="cars">
                    <div className="car" id="no-cars">
                        {cars.length === 0
                            ? 'Você não tem nenhum carro cadastrado. Para visualizar o diagnóstico do serviço você deve adicionar um carro.'
                            : cars.map((car, index) => <div key={index} className="car">{car}</div>)
                        }
                    </div>
                    <input
                        className="Add"
                        type="text"
                        placeholder="Informações do carro"
                        onChange={(e) => setInfo(e.target.value)}
                        value={info}
                    />
                    <br />
                    <br />
                    <div className="header">
                        <button onClick={addCar}>Adicionar</button>
                    </div>
                </div>
                <div className="steps">
                    <div className="step">
                        <h2>Informações</h2>
                        <p>Adicione informações sobre o que está acontecendo para visualizar o panorama.</p>
                        <input
                            className="Add"
                            type="text"
                            placeholder="Informações do carro"
                            onChange={(e) => setInfo(e.target.value)}
                            value={info}
                        />
                        <br />
                        <br />
                        <button onClick={addInfo}>Adicionar</button>
                    </div>
                    <div className="step">
                        <h2>Panorama</h2>
                        <p>Receba o panorama</p>
                        <button onClick={getPanorama}>Receber</button>
                    </div>
                    <div className="step">
                        <h2>Diagnóstico</h2>
                        <p>Receba o Diagnóstico gerado através do panorama</p>
                        <button onClick={getDiagnosis}>Receber</button>
                    </div>
                    <div className="step">
                        <h2>Orçamento</h2>
                        <p>Digite seu e-mail e receba o orçamento no email</p>
                        <form onSubmit={handleSubmit}>
                            <input
                                className="Add"
                                type="email"
                                placeholder="e-mail"
                                onChange={(e) => setEmail(e.target.value)}
                                value={email}
                            />
                            <br />
                            <br />
                            <button className="Add" type="submit">Enviar</button>
                        </form>
                    </div>
                </div>
            </div>
        </>

    )
}

export default Diagnostico;
